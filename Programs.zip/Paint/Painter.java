public class Painter
{
	public static void main(String args[])
	{
		PaintWindow window=new PaintWindow();
	}
}