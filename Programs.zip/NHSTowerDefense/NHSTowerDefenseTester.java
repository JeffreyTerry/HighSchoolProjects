public class NHSTowerDefenseTester
{
	public static void main(String args[])
	{
		TowerDefenseFrame app=new TowerDefenseFrame();
	}
}
